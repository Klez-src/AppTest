Put the existing primordial.png and gamesense.png assets in this folder.

The loader should be configured to navigate to:
http://localhost:3000/loader/

Its JavaScript can read the subscription state because it is served from the same origin as the site.

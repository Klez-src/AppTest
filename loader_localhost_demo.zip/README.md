# Local Loader Demo

Run:

```powershell
npx serve . -l 3000
```

Open `http://localhost:3000/`.

Create an account, use Store to get the three free demo subscriptions, then point the WebView2 loader at `http://localhost:3000/loader/`.

Subscriptions are deliberately stored in localStorage. This is a mock/demo system, not real authentication or payments.
